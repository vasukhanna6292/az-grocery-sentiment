from pathlib import Path
import sys
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report, accuracy_score

# Derive project root from this file's location: <root>/src/models/train_ml.py
BASE = Path(__file__).resolve().parents[2]  # -> project root
DATA_FILE = BASE / "data" / "processed" / "reviews_clean.csv"

if not DATA_FILE.exists():
    sys.exit(f"[ERROR] {DATA_FILE} not found. Run: python src/data/make_dataset.py")

def main():
    print(f"Loading: {DATA_FILE}")
    df = pd.read_csv(DATA_FILE)
    X_train, X_test, y_train, y_test = train_test_split(
        df['text'], df['label'], test_size=0.2, random_state=42, stratify=df['label']
    )
    tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1,2))
    Xtr = tfidf.fit_transform(X_train)
    Xte = tfidf.transform(X_test)

    models = {
        'logreg_lbfgs': LogisticRegression(max_iter=2000),
        'svm_linear': LinearSVC(),
        'naive_bayes': MultinomialNB()
    }

    for name, model in models.items():
        model.fit(Xtr, y_train)
        pred = model.predict(Xte)
        print(f"\n=== {name.upper()} ===")
        print('Accuracy:', round(accuracy_score(y_test, pred), 4))
        print(classification_report(y_test, pred, digits=4))

if __name__ == '__main__':
    main()