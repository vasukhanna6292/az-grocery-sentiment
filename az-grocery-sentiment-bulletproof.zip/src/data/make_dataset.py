from pathlib import Path
import csv, random

# Derive project root from this file's location: <root>/src/data/make_dataset.py
BASE = Path(__file__).resolve().parents[2]  # -> project root

PROCESSED = BASE / "data" / "processed"
PROCESSED.mkdir(parents=True, exist_ok=True)
out_csv = PROCESSED / "reviews_clean.csv"

examples_pos = [
    "Loved the fresh produce and friendly staff.",
    "Great prices and quick checkout.",
    "Store was clean and well organized. Will return!",
    "Bakery items were delicious and fresh.",
    "Excellent selection of organic products."
]
examples_neu = [
    "Found most of what I needed.",
    "The store was okay, nothing special.",
    "Average experience; aisles were fine.",
    "Stopped by for basics; in and out.",
    "Typical grocery store visit."
]
examples_neg = [
    "Long checkout lines and empty shelves.",
    "Rude staff and poor stock management.",
    "Overpriced items and messy aisles.",
    "Bakery quality was disappointing.",
    "Waited 20 minutes; very frustrating."
]

rows = []
for _ in range(180):
    bucket = random.choice([0,1,2])
    if bucket == 0:
        text = random.choice(examples_neg)
    elif bucket == 1:
        text = random.choice(examples_neu)
    else:
        text = random.choice(examples_pos)
    rows.append((text, bucket))

with out_csv.open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['text','label'])
    w.writerows(rows)

print(f"Wrote SAMPLE dataset to {out_csv}")